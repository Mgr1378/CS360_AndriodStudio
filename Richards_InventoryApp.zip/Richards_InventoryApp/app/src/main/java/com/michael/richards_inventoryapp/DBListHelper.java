package com.michael.richards_inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBListHelper extends SQLiteOpenHelper {

    public DBListHelper (Context context) {
        super(context, "Productdata.db", null,1 );
    }

    @Override
    public void onCreate(SQLiteDatabase productDB) {
        productDB.execSQL("create Table Productdetails(product Text primary key, description TEXT, quantity TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase productDB, int i, int i1) {
        productDB.execSQL("drop Table if exists Productdetails");

    }

    public Boolean addProductData(String product, String desc, String qty){
        SQLiteDatabase productDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("product", product);
        contentValues.put("description", desc);
        contentValues.put("quantity", qty);
        long result = productDB.insert("Productdetails", null, contentValues);
        if(result == -1){
            return false;
        }else {
            return true;
        }
    }

    public Boolean editProductData(String product, String desc, String qty){
        SQLiteDatabase productDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("description", desc);
        contentValues.put("quantity", qty);
        Cursor cursor = productDB.rawQuery("Select * from Productdetails where product = ?", new String[]{product});
        if(cursor.getCount()>0) {


            long result = productDB.update("Productdetails", contentValues, "product=?", new String[]{product});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }else{
            return false;
        }
    }

    public Boolean deleteProductData(String product){
        SQLiteDatabase productDB = this.getWritableDatabase();
        Cursor cursor = productDB.rawQuery("Select * from Productdetails where product = ?", new String[]{product});
        if(cursor.getCount()>0) {


            long result = productDB.delete("Productdetails", "product=?", new String[]{product});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }else{
            return false;
        }
    }

    public Cursor ViewProductData(){
        SQLiteDatabase productDB = this.getWritableDatabase();
        Cursor cursor = productDB.rawQuery("Select * from Productdetails ", null);
        return cursor;
    }

}
