package com.michael.richards_inventoryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    private int SMS_PERMISSION_CODE = 1;

    EditText product, desc, qty;
    Button add, edit, delete, view, smsPermission;
    DBListHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        product = findViewById(R.id.product);
        desc = findViewById(R.id.description);
        qty = findViewById(R.id.quantity);

        add = findViewById(R.id.addProductButton);
        edit = findViewById(R.id.editProductButton);
        delete = findViewById(R.id.deleteProductButton);
        view = findViewById(R.id.viewProductButton);

        smsPermission = findViewById(R.id.smsPermission);

        DB = new DBListHelper(this);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String productTEXT = product.getText().toString();
                String descTEXT = desc.getText().toString();
                String qtyTEXT = qty.getText().toString();

                Boolean checkAddData = DB.addProductData(productTEXT, descTEXT, qtyTEXT);
                if(checkAddData)
                    Toast.makeText(HomeActivity.this, "New Product has been added", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(HomeActivity.this, "New Product has failed to be added", Toast.LENGTH_SHORT).show();
            }
        });

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String productTEXT = product.getText().toString();
                String descTEXT = desc.getText().toString();
                String qtyTEXT = qty.getText().toString();

                Boolean checkEditData = DB.editProductData(productTEXT, descTEXT, qtyTEXT);
                if(checkEditData)
                    Toast.makeText(HomeActivity.this, "Product has been updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(HomeActivity.this, "Product has failed to update", Toast.LENGTH_SHORT).show();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String productTEXT = product.getText().toString();


                Boolean checkDeleteData = DB.deleteProductData(productTEXT);
                if(checkDeleteData)
                    Toast.makeText(HomeActivity.this, "Product has been deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(HomeActivity.this, "Product has failed to delete", Toast.LENGTH_SHORT).show();
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = DB.ViewProductData();
                if(res.getCount() == 0){
                    Toast.makeText(HomeActivity.this, "No Product Exists", Toast.LENGTH_SHORT).show();
                return;
                }

                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("Product : "+ res.getString(0) + "\n");
                    buffer.append("Description : "+ res.getString(1) + "\n");
                    buffer.append("Quantity : "+ res.getString(2) + "\n\n");
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
                builder.setCancelable(true);
                builder.setTitle("Product Data");
                builder.setMessage(buffer.toString());
                builder.show();

            }
        });

        smsPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ContextCompat.checkSelfPermission(HomeActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(HomeActivity.this, "Permission Already Granted", Toast.LENGTH_SHORT).show();
                }
                else {
                    requestSmsPermission();
                }
            }
        });
    }

    private void requestSmsPermission(){
        if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)){

            new AlertDialog.Builder(this)
                    .setTitle("Permission Needed")
                    .setMessage("Allows app to send sms messages when inventory is low or at zero")
                    .setPositiveButton("Accept", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ActivityCompat.requestPermissions(HomeActivity.this, new String[] {Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE );

                        }
                    })
                    .setNegativeButton("Deny", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    })
                    .create().show();


        }else{
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE );
        }
    }


    //check to see if permission has
    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }

    }
}